const form = document.getElementById("chatForm");
const input = document.getElementById("chatInput");
const messages = document.getElementById("messages");
const voiceInput = document.getElementById("voiceInput");
const speakToggle = document.getElementById("speakToggle");
const consentPanel = document.getElementById("consentPanel");
const acceptConsent = document.getElementById("acceptConsent");
const skipConsent = document.getElementById("skipConsent");
const openConsent = document.getElementById("openConsent");
const memoryConsent = document.getElementById("memoryConsent");
const companionConsent = document.getElementById("companionConsent");
const apiUrlInput = document.getElementById("apiUrlInput");
const saveApiUrl = document.getElementById("saveApiUrl");
const apiStatus = document.getElementById("apiStatus");
const companion = document.getElementById("companion");
const toggleCompanion = document.getElementById("toggleCompanion");
const installApp = document.getElementById("installApp");
const installPanel = document.getElementById("installPanel");
const closeInstall = document.getElementById("closeInstall");
const installStatus = document.getElementById("installStatus");
const swatches = document.querySelectorAll("[data-companion]");
const quickChat = document.getElementById("quickChat");
const quickChatBody = document.getElementById("quickChatBody");
const quickChatForm = document.getElementById("quickChatForm");
const quickChatInput = document.getElementById("quickChatInput");
const quickVoiceInput = document.getElementById("quickVoiceInput");
const closeQuickChat = document.getElementById("closeQuickChat");
const onboarding = document.getElementById("onboarding");
const onboardingName = document.getElementById("onboardingName");
const onboardingMemory = document.getElementById("onboardingMemory");
const onboardingCompanion = document.getElementById("onboardingCompanion");
const finishOnboarding = document.getElementById("finishOnboarding");
const onboardingSteps = [...document.querySelectorAll("[data-step]")];
const onboardingDots = [...document.querySelectorAll("[data-step-dot]")];
const nextStepButtons = [...document.querySelectorAll("[data-next-step]")];

let companionMoveTimer = null;
let dragState = null;
let installPrompt = null;
let voiceEnabled = localStorage.getItem("ray_voice_reply") === "yes";
let onboardingStep = 0;

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

const rememberSetting = (key, value) => localStorage.setItem(`ray_${key}`, value);
const readSetting = (key) => localStorage.getItem(`ray_${key}`);
const clamp = (value, min, max) => Math.min(Math.max(value, min), max);
const cleanUrl = (value) => value.trim().replace(/\/+$/, "");
const getApiUrl = () => cleanUrl(readSetting("api_url") || window.RAY_API_URL || "");

const isStandalone = () => (
  window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true
);

const isIos = () => /iphone|ipad|ipod/i.test(window.navigator.userAgent);

const showOnboardingStep = (step) => {
  onboardingStep = clamp(step, 0, onboardingSteps.length - 1);
  onboardingSteps.forEach((item, index) => item.classList.toggle("active", index === onboardingStep));
  onboardingDots.forEach((item, index) => item.classList.toggle("active", index === onboardingStep));
};

const collectPurposes = () => (
  [...document.querySelectorAll(".purpose-grid input:checked")].map((item) => item.value)
);

const setApiStatus = (text, isOk = false) => {
  if (!apiStatus) return;
  apiStatus.textContent = text;
  apiStatus.classList.toggle("ok", isOk);
};

const addMessage = (text, type = "ray", target = messages) => {
  const node = document.createElement("div");
  node.className = `message ${type}`;
  node.textContent = text;
  target.appendChild(node);
  target.scrollTop = target.scrollHeight;
  return node;
};

const speak = (text) => {
  if (!voiceEnabled || !("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "ru-RU";
  utterance.rate = 1;
  utterance.pitch = 1;
  window.speechSynthesis.speak(utterance);
};

const localRayReply = (text) => {
  const lower = text.toLowerCase();
  if (lower.includes("привет") || lower.includes("хай")) return "Привет. Я рядом. Что делаем?";
  if (lower.includes("цель") || lower.includes("план")) return "Давай коротко: цель, срок и первый маленький шаг на сегодня.";
  if (lower.includes("устал") || lower.includes("плохо") || lower.includes("груст")) return "Слышу. Сначала выдох. Напиши, что самое тяжёлое прямо сейчас.";
  if (lower.includes("англий")) return "Ок. Для английского: 15 минут слов, 10 минут аудио и одна короткая фраза вслух.";
  if (lower.includes("картин") || lower.includes("фото")) return "Фото и картинки лучше отправлять в Telegram-бота. В Web я подключу это через Ray API.";
  return "Понял. Давай проще: что ты хочешь получить в итоге?";
};

const askRay = async (text, target = messages) => {
  addMessage(text, "user", target);
  const thinking = addMessage("Думаю...", "ray", target);
  const apiUrl = getApiUrl();

  if (apiUrl) {
    try {
      const response = await fetch(`${apiUrl}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          session_id: readSetting("session_id") || undefined,
          message: text,
        }),
      });
      if (!response.ok) throw new Error(`Ray API ${response.status}`);
      const data = await response.json();
      if (data.session_id) rememberSetting("session_id", data.session_id);
      const reply = data.reply || "Я рядом. Скажи чуть подробнее?";
      thinking.textContent = reply;
      speak(reply);
      return;
    } catch (error) {
      thinking.textContent = "Связь с Ray API сейчас не отвечает. Пока отвечу локально.";
    }
  }

  window.setTimeout(() => {
    const reply = localRayReply(text);
    thinking.textContent = reply;
    speak(reply);
  }, 320);
};

const syncProfile = async () => {
  const apiUrl = getApiUrl();
  if (!apiUrl || readSetting("memory_allowed") !== "yes") return;

  const sessionId = readSetting("session_id") || `web-${window.crypto?.randomUUID?.() || Date.now()}`;
  rememberSetting("session_id", sessionId);

  try {
    await fetch(`${apiUrl}/profile`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: sessionId,
        name: readSetting("profile_name") || "",
        purposes: JSON.parse(readSetting("purposes") || "[]"),
        memory_allowed: readSetting("memory_allowed") === "yes",
        companion_allowed: readSetting("companion_allowed") === "yes",
      }),
    });
  } catch (error) {
    setApiStatus("API сохранён, но профиль пока не отправился. После деплоя Render попробуем снова.");
  }
};

const startVoiceInput = (targetInput, button) => {
  if (!SpeechRecognition) {
    addMessage("Голосовой ввод в этом браузере не поддерживается. На iPhone попробуй диктовку клавиатуры.", "ray");
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.lang = "ru-RU";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  button.classList.add("active");
  recognition.onresult = (event) => {
    targetInput.value = event.results[0][0].transcript;
    targetInput.focus();
  };
  recognition.onerror = () => {
    addMessage("Не получилось услышать голос. Проверь разрешение микрофона.", "ray");
  };
  recognition.onend = () => button.classList.remove("active");
  recognition.start();
};

const companionBounds = () => {
  const rect = companion.getBoundingClientRect();
  const margin = 12;
  return {
    width: rect.width || 58,
    height: rect.height || 58,
    minX: margin,
    minY: margin,
    maxX: window.innerWidth - (rect.width || 58) - margin,
    maxY: window.innerHeight - (rect.height || 58) - 104,
  };
};

const placeCompanion = (x, y, save = true) => {
  const bounds = companionBounds();
  const safeX = clamp(x, bounds.minX, bounds.maxX);
  const safeY = clamp(y, bounds.minY, bounds.maxY);
  companion.style.left = `${safeX}px`;
  companion.style.top = `${safeY}px`;
  companion.style.right = "auto";
  companion.style.bottom = "auto";

  if (save) {
    rememberSetting("companion_x", String(Math.round(safeX)));
    rememberSetting("companion_y", String(Math.round(safeY)));
  }
};

const restoreCompanionPosition = () => {
  const savedX = Number(readSetting("companion_x"));
  const savedY = Number(readSetting("companion_y"));
  if (Number.isFinite(savedX) && Number.isFinite(savedY)) {
    placeCompanion(savedX, savedY, false);
    return;
  }

  const bounds = companionBounds();
  placeCompanion(bounds.maxX, bounds.maxY, false);
};

const randomCompanionMove = () => {
  if (readSetting("companion_allowed") !== "yes" || companion.classList.contains("hidden")) return;

  const bounds = companionBounds();
  const x = bounds.minX + Math.random() * (bounds.maxX - bounds.minX);
  const y = bounds.minY + Math.random() * (bounds.maxY - bounds.minY);
  companion.style.transition = "left 800ms ease, top 800ms ease";
  placeCompanion(x, y, true);
  window.setTimeout(() => {
    companion.style.transition = "";
  }, 850);
};

const startCompanionMovement = () => {
  window.clearInterval(companionMoveTimer);
  if (readSetting("companion_allowed") === "yes") {
    companionMoveTimer = window.setInterval(randomCompanionMove, 11000);
  }
};

const showConsent = () => {
  memoryConsent.checked = readSetting("memory_allowed") === "yes";
  companionConsent.checked = readSetting("companion_allowed") === "yes";
  if (apiUrlInput) apiUrlInput.value = getApiUrl();
  setApiStatus(getApiUrl()
    ? "Ray API подключён. Чат будет отвечать через backend."
    : "Ray API ещё не подключён. Чат работает локально, без общей памяти между устройствами."
  , Boolean(getApiUrl()));
  consentPanel.classList.add("show");
};

const hideConsent = () => consentPanel.classList.remove("show");
const showInstall = () => installPanel.classList.add("show");
const hideInstall = () => installPanel.classList.remove("show");
const companionAllowed = () => readSetting("companion_allowed") === "yes";

if (readSetting("onboarding_done") === "yes") {
  onboarding.classList.remove("show");
  if (!readSetting("privacy_seen")) showConsent();
} else {
  showOnboardingStep(0);
}

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/ray_site/sw.js", { scope: "/ray_site/" }).catch(() => {});
  });
}

window.addEventListener("beforeinstallprompt", (event) => {
  event.preventDefault();
  installPrompt = event;
  installApp.disabled = false;
  installStatus.textContent = "Установка доступна. Нажми «Установить», и браузер откроет системное окно.";
});

window.addEventListener("appinstalled", () => {
  installPrompt = null;
  installStatus.textContent = "Рэй установлен. Его можно открыть с экрана телефона или из приложений на компьютере.";
  installApp.textContent = "Установлено";
});

installApp.addEventListener("click", async () => {
  if (isStandalone()) {
    installStatus.textContent = "Рэй уже открыт как установленное приложение.";
    showInstall();
    return;
  }

  if (!installPrompt) {
    installStatus.textContent = isIos()
      ? "На iPhone установка идёт через Safari: Поделиться → На экран Домой."
      : "Если системное окно не появилось, открой сайт в Chrome или Edge и нажми значок установки в адресной строке.";
    showInstall();
    return;
  }

  installPrompt.prompt();
  const choice = await installPrompt.userChoice;
  installStatus.textContent = choice.outcome === "accepted"
    ? "Установка началась. После этого Рэй появится как приложение."
    : "Установку отменили. Можно попробовать ещё раз позже.";
  installPrompt = null;
});

closeInstall.addEventListener("click", hideInstall);
openConsent.addEventListener("click", showConsent);
nextStepButtons.forEach((button) => {
  button.addEventListener("click", () => showOnboardingStep(onboardingStep + 1));
});

finishOnboarding.addEventListener("click", async () => {
  rememberSetting("onboarding_done", "yes");
  rememberSetting("privacy_seen", "yes");
  rememberSetting("profile_name", onboardingName.value.trim());
  rememberSetting("purposes", JSON.stringify(collectPurposes()));
  rememberSetting("memory_allowed", onboardingMemory.checked ? "yes" : "no");
  rememberSetting("companion_allowed", onboardingCompanion.checked ? "yes" : "no");
  onboarding.classList.remove("show");
  setCompanionVisible(onboardingCompanion.checked);
  startCompanionMovement();
  addMessage("Готово. Я здесь, можно писать или говорить.", "ray");
  speak("Готово. Я здесь.");
  await syncProfile();
});

skipConsent.addEventListener("click", () => {
  rememberSetting("privacy_seen", "yes");
  rememberSetting("memory_allowed", "no");
  rememberSetting("companion_allowed", "no");
  setCompanionVisible(false);
  hideConsent();
  startCompanionMovement();
});

acceptConsent.addEventListener("click", () => {
  rememberSetting("privacy_seen", "yes");
  rememberSetting("memory_allowed", memoryConsent.checked ? "yes" : "no");
  rememberSetting("companion_allowed", companionConsent.checked ? "yes" : "no");
  setCompanionVisible(companionConsent.checked);
  hideConsent();
  startCompanionMovement();
  if (companionConsent.checked) randomCompanionMove();
  syncProfile();
});

saveApiUrl?.addEventListener("click", async () => {
  const value = cleanUrl(apiUrlInput.value || "");
  if (value && !/^https?:\/\//i.test(value)) {
    setApiStatus("Ссылка API должна начинаться с https:// или http://");
    return;
  }
  if (value) rememberSetting("api_url", value);
  else localStorage.removeItem("ray_api_url");

  if (!value) {
    setApiStatus("API отключён. Рэй будет отвечать локально, без общей памяти.");
    return;
  }

  setApiStatus("Проверяю Ray API...");
  try {
    const response = await fetch(`${value}/health`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    setApiStatus("Ray API подключён. Теперь чат отвечает через backend.", true);
    await syncProfile();
  } catch (error) {
    setApiStatus("Ссылка сохранена, но API сейчас не отвечает. Проверь Render URL и переменные.");
  }
});

const applyCompanionColor = (color) => {
  document.body.classList.remove("companion-amber", "companion-blue", "companion-rose");
  if (color !== "teal") document.body.classList.add(`companion-${color}`);
  swatches.forEach((button) => button.classList.toggle("active", button.dataset.companion === color));
  rememberSetting("companion_color", color);
};

const setCompanionVisible = (visible) => {
  companion.classList.toggle("hidden", !visible);
  toggleCompanion.textContent = visible ? "●" : "○";
  rememberSetting("companion_visible", visible ? "yes" : "no");
};

const openQuickChat = () => {
  if (!companionAllowed()) {
    showConsent();
    return;
  }
  quickChat.classList.add("show");
  quickChatInput.focus();
};

const pointerPosition = (event) => {
  const point = event.touches ? event.touches[0] : event;
  return { x: point.clientX, y: point.clientY };
};

companion.addEventListener("pointerdown", (event) => {
  if (!companionAllowed()) {
    showConsent();
    return;
  }
  if (event.button && event.button !== 0) return;
  const point = pointerPosition(event);
  const rect = companion.getBoundingClientRect();
  dragState = {
    offsetX: point.x - rect.left,
    offsetY: point.y - rect.top,
    moved: false,
  };
  companion.classList.add("dragging");
  companion.setPointerCapture(event.pointerId);
});

companion.addEventListener("pointermove", (event) => {
  if (!dragState) return;
  const point = pointerPosition(event);
  dragState.moved = true;
  placeCompanion(point.x - dragState.offsetX, point.y - dragState.offsetY, false);
});

const endDrag = (event) => {
  if (!dragState) return;
  const rect = companion.getBoundingClientRect();
  const moved = dragState.moved;
  dragState = null;
  companion.classList.remove("dragging");
  placeCompanion(rect.left, rect.top, true);
  if (event.pointerId !== undefined && companion.hasPointerCapture(event.pointerId)) {
    companion.releasePointerCapture(event.pointerId);
  }
  if (!moved) openQuickChat();
};

companion.addEventListener("pointerup", endDrag);
companion.addEventListener("pointercancel", endDrag);
companion.addEventListener("dblclick", openQuickChat);

window.addEventListener("resize", () => {
  const rect = companion.getBoundingClientRect();
  placeCompanion(rect.left, rect.top, true);
});

applyCompanionColor(readSetting("companion_color") || "teal");
setCompanionVisible(companionAllowed() && readSetting("companion_visible") !== "no");
restoreCompanionPosition();
startCompanionMovement();
speakToggle.classList.toggle("active", voiceEnabled);

swatches.forEach((button) => {
  button.addEventListener("click", () => applyCompanionColor(button.dataset.companion));
});

toggleCompanion.addEventListener("click", () => {
  if (!companionAllowed()) {
    showConsent();
    return;
  }
  setCompanionVisible(companion.classList.contains("hidden"));
});

voiceInput.addEventListener("click", () => startVoiceInput(input, voiceInput));
quickVoiceInput.addEventListener("click", () => startVoiceInput(quickChatInput, quickVoiceInput));

speakToggle.addEventListener("click", () => {
  voiceEnabled = !voiceEnabled;
  localStorage.setItem("ray_voice_reply", voiceEnabled ? "yes" : "no");
  speakToggle.classList.toggle("active", voiceEnabled);
  if (voiceEnabled) speak("Ок, буду отвечать голосом.");
  else window.speechSynthesis?.cancel();
});

closeQuickChat.addEventListener("click", () => quickChat.classList.remove("show"));

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  input.value = "";
  await askRay(text, messages);
});

quickChatForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const text = quickChatInput.value.trim();
  if (!text) return;
  quickChatInput.value = "";
  await askRay(text, quickChatBody);
});
